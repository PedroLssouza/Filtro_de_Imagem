/**************************************************************************
*                                                                         *
*           Universidade Federal do Maranhão                              *
*       Departamento de Engenharia da Computação                          *
*                                                                         *
*  Author: Prof. Dr. Thales Levi Azevedo Valente                           *
*                                                                         *
*  Description: Processamento de Imagens em C                              *
*                                                                         *
*  Date: 27-11-2023                                                       *
*                                                                         *
* Este material fornece um programa simples para processamento de imagens *
* em C, incluindo filtros como negativo, escala de cinza, blur e Sobel.    *
*                                                                         *
* Conteúdos do Material:                                                  *
*   1. Carregamento de uma imagem em C                                    *
*   2. Aplicação de filtros: negativo, escala de cinza, blur e Sobel       *
*   3. Salvamento da imagem processada                                    *
*   4. Manipulação de Dados e Ponteiros                                   *
*   5. Criação de Menu                                                   *
*                                                                         *
***************************************************************************
* -------------------------------------------------------------------------*
*   IMPORTANTE:                                                           *
*   1- NÃO modifique a assinatura das funções (tipo retorno, nome, parâm.)*
*   2- Apenas implemente o corpo das funções trocando o ; por chaves      *
*   3- NÃO modifique a main                                               *
*   4- Veja o arquivo "exemplo.c"                                         *
*   5- NOME DO ARQUIVO É "NOME_SOBRENOME1_SOBRENOME2"                     *
* -------------------------------------------------------------------------*
*                                                                         *
* Inicie o código abaixo para começar a exploração.                       *
*                                                                         *
***************************************************************************/
//Inclusao das bibliotecas, inclusive as de manipulacao de imagens
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

//Funcoes de cada filtro e de salvamento
void applyNegativeFilter(unsigned char *img, int width, int height, int channels);
void applyGrayScaleFilter(unsigned char *img, int width, int height, int channels);
void applyBlurFilter(unsigned char *img, int width, int height, int channels);
void applySobelFilter(unsigned char *img, int width, int height, int channels);
void saveImage(const unsigned char *img, int width, int height, int channels, const char *outputFileName);

int main() { //Funcao principal
    //Local da imagem 
    int width, height, channels;
    char inputFile[100] = "C:\\Users\\pdrog\\Documents\\C image\\projeto_de_C\\falcao.jpg";
    char outputFileName[100];

    //Carregar a imagem
    unsigned char *img = stbi_load(inputFile, &width, &height, &channels, 0);
    if (img == NULL) {
        fprintf(stderr, "Erro ao carregar a imagem.\n");
        return 1;
    }

    //Criar uma copia inicial da imagem
    unsigned char *temp = malloc(width * height * channels);
    memcpy(temp, img, width * height * channels);

    int choice; //Loop do menu
    do { 
        //Copiar a imagem temporaria de volta para a imagem de trabalho
        memcpy(img, temp, width * height * channels);

        printf("\nEscolha o filtro a ser aplicado:\n"); 
        printf("1: Negativo\n");
        printf("2: Escala de Cinza\n");
        printf("3: Blur\n");
        printf("4: Sobel\n");
        printf("5: Sair\n");
        printf("Digite sua escolha: ");
        scanf("%d", &choice);

        switch (choice) { //Funcoes dos filtros e de salvar a imagem em cada escolha
        case 1:
            applyNegativeFilter(img, width, height, channels);
            strcpy(outputFileName, "negativo.jpg");
            break;
        case 2:
            applyGrayScaleFilter(img, width, height, channels);
            strcpy(outputFileName, "escala_de_cinza.jpg");
            break;
        case 3:
            applyBlurFilter(img, width, height, channels);
            strcpy(outputFileName, "blur.jpg");
            break;
        case 4:
            applyGrayScaleFilter(img, width, height, channels); //Para o Sobel, primeiro converter para escala de cinza
            applySobelFilter(img, width, height, channels);
            strcpy(outputFileName, "sobel.jpg");
            break;
        case 5: //Fim do loop
            printf("Programa encerrado.\n");
            break;
        default:
            printf("Escolha invalida!\n");
            break;
        }

        //Salvar a imagem processada com o nome apropriado (exceto para a opcao 5)
        if (choice != 5) {
            saveImage(img, width, height, channels, outputFileName);
        }

    } while (choice != 5);

    //Liberar memoria
    stbi_image_free(img);
    free(temp);
    return 0;
}
//Filtro sobel
void applySobelFilter(unsigned char *img, int width, int height, int channels) {
    unsigned char *temp = malloc(width * height * channels * sizeof(unsigned char));
    //Loop para percorrer cada pixel da imagem, com excecao das bordas
    for (int i = 1; i < height - 1; ++i) {
        for (int j = 1; j < width - 1; ++j) {
            for (int k = 0; k < channels; ++k) {
                //Indice do pixel no array unidimensional
                int index = (i * width + j) * channels + k;
                //Aplicar os kernels de matriz em X e Y
                int Gx = -img[((i - 1) * width + (j - 1)) * channels + k] +
                         img[((i - 1) * width + (j + 1)) * channels + k] +
                         -2 * img[(i * width + (j - 1)) * channels + k] +
                         2 * img[(i * width + (j + 1)) * channels + k] +
                         -img[((i + 1) * width + (j - 1)) * channels + k] +
                         img[((i + 1) * width + (j + 1)) * channels + k];
                int Gy = -img[((i - 1) * width + (j - 1)) * channels + k] +
                         -2 * img[((i - 1) * width + j) * channels + k] +
                         -img[((i - 1) * width + (j + 1)) * channels + k] +
                         img[((i + 1) * width + (j - 1)) * channels + k] +
                         2 * img[((i + 1) * width + j) * channels + k] +
                         img[((i + 1) * width + (j + 1)) * channels + k];

                //Calcular a magnitude do gradiente usando a distância euclidiana
                float magnitude = sqrt(Gx * Gx + Gy * Gy);
                //Armazenar o valor da magnitude na imagem temporaria
                temp[index] = (unsigned char)fmin(255.0, magnitude); //Limitar a 255
            }
        }
    }
    //Copiar a imagem gerada de volta para a imagem original
    memcpy(img, temp, width * height * channels * sizeof(unsigned char));
    //Liberar memoria usada para a imagem temporária
    free(temp);
}
//Funcao salvamento
void saveImage(const unsigned char *img, int width, int height, int channels, const char *outputFileName) {
    char outputPath[200];
    sprintf(outputPath, "C:\\Users\\pdrog\\Documents\\C image\\projeto_de_C\\%s", outputFileName); //Constroi o caminho no diretorio atual
    stbi_write_jpg(outputPath, width, height, channels, img, 100);
    printf("%s", outputPath);
}
//Filtro negativo
void applyNegativeFilter(unsigned char *img, int width, int height, int channels) {
    for (int i = 0; i < width * height * channels; ++i) {
    	img[i] = 255 - img[i]; //Para cada pixel: Invertido = 255 - Original
    }
}
//Filtro de escala de cinza
void applyGrayScaleFilter(unsigned char *img, int width, int height, int channels) {
    for (int i = 0; i < width * height * channels; i += channels) {
        int cinza = 0.3 * img[i] + 0.59 * img[i + 1] + 0.11 * img[i + 2];
        img[i] = img[i + 1] = img[i + 2] = cinza;
    }
}
//Filtro de desfoque
void applyBlurFilter(unsigned char *img, int width, int height, int channels) {
    unsigned char *temp = malloc(width * height * channels);
    memcpy(temp, img, width * height * channels);
    for (int i = 1; i < height - 1; i++) { //Loop do filtro
        for (int j = 3; j < width * 3 - 3; j += 3) {
            for (int k = 0; k < 3; k++) {
                img[i * width * 3 + j + k] = (img[(i - 1) * width * 3 + j + k] + img[i * width * 3 + j - 3 + k] + img[i * width * 3 + j + k] + img[i * width * 3 + j + 3 + k] + img[(i + 1) * width * 3 + j + k]) / 5;
            }
        }
    }
    //Liberar memoria usada para a imagem temporaria
    free(temp);
}
